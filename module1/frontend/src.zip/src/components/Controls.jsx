import { useState } from 'react';
import StPanel from './StPanel';

/**
 * Controls — Sidebar control panel for the Image Workbench.
 * Panels 5-8 of the ScanTailor workflow.
 */
export default function Controls({
  onTransform, onDewarp, onDewarpAuto,
  onEnhance, onReset, onUndo, onExportPdf,
  onAnalyzeGrid,
  loading, hasImage, hasTransformed, canUndo, pageCount,
  dewarpGridActive = false,
  perspectiveOpen, onPerspectiveToggle,
  dewarpOpen, onDewarpToggle,
  dewarpMode = 'manual', onDewarpModeChange,
}) {
  const [dewarpStrength, setDewarpStrength] = useState(1.0);
  const [outputFormat,   setOutputFormat]   = useState('bw');
  const [enhanceType,    setEnhanceType]    = useState('otsu');

  const disabled = loading || !hasImage;

  return (
    <div className="st-panels-block">

      {/* ── Panel 5: Perspective Transform ── */}
      <StPanel number={5} title="Perspective Correct" open={perspectiveOpen} onToggle={onPerspectiveToggle}>
        <p style={{ fontSize: 11, color: 'var(--color-text-3)', lineHeight: 1.55, marginBottom: 10 }}>
          Drag the corner handles on the canvas, then apply.
        </p>
        <button
          className="btn w-full"
          onClick={onTransform}
          disabled={disabled}
          id="btn-transform"
          style={{ background: 'linear-gradient(135deg,#7c4dff,#5b37c0)', color: '#fff',
            boxShadow: disabled ? 'none' : '0 0 18px rgba(124,77,255,0.3)' }}
        >
          {loading ? <span className="spinner" /> : '⊞'} Apply Transform
        </button>
      </StPanel>

      {/* ── Panel 6: Grid Dewarp ── */}
      <StPanel number={6} title="Grid Dewarp" open={dewarpOpen} onToggle={onDewarpToggle}>

        {/* ── Mode toggle: Auto / Manual ── */}
        <div style={{ marginBottom: 10 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--color-text-3)',
                        letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 6 }}>
            Mode
          </div>
          <div style={{ display: 'flex', borderRadius: 7, overflow: 'hidden',
                        border: '1.5px solid var(--color-border)' }}>
            {['auto', 'manual'].map((m) => (
              <button key={m} disabled={disabled} onClick={() => onDewarpModeChange?.(m)}
                style={{
                  flex: 1, padding: '5px 0',
                  background: dewarpMode === m ? 'rgba(0,229,255,0.15)' : 'var(--color-surface-3)',
                  color: dewarpMode === m ? 'var(--color-cyan)' : 'var(--color-text-3)',
                  border: 'none', cursor: disabled ? 'not-allowed' : 'pointer',
                  fontWeight: 700, fontSize: 11, letterSpacing: '0.06em',
                  textTransform: 'uppercase', transition: 'all 0.15s',
                }}>
                {m === 'auto' ? '✦ Auto' : '⊞ Manual'}
              </button>
            ))}
          </div>
        </div>

        {/* ── AUTO mode ── */}
        {dewarpMode === 'auto' && (
          <>
            <div style={{
              fontSize: 10, color: 'var(--color-text-3)', lineHeight: 1.6,
              background: 'rgba(0,229,255,0.05)', borderRadius: 6,
              padding: '7px 8px', border: '1px solid rgba(0,229,255,0.18)',
              marginBottom: 10,
            }}>
              ✦ <strong style={{ color: 'var(--color-cyan)' }}>Neural network mode</strong><br />
              ICCV 2023 model automatically detects and corrects document warping.<br />
              No grid interaction required.
            </div>
            <button
              className="btn w-full"
              onClick={onDewarpAuto}
              disabled={disabled}
              id="btn-dewarp-auto"
              style={{
                background: disabled
                  ? 'var(--color-surface-3)'
                  : 'linear-gradient(135deg,#00e5ff,#7c4dff)',
                color: disabled ? 'var(--color-text-3)' : '#fff',
                boxShadow: disabled ? 'none' : '0 0 18px rgba(0,229,255,0.3)',
              }}
            >
              {loading ? <span className="spinner" /> : '✦'} Apply Auto Dewarp
            </button>
          </>
        )}

        {/* ── MANUAL mode ── */}
        {dewarpMode === 'manual' && (
          <>
            {/* Analyze grid toggle */}
            <button
              className="btn w-full btn-sm"
              onClick={onAnalyzeGrid}
              disabled={disabled}
              id="btn-analyze-grid"
              style={{
                marginBottom: 10,
                background: dewarpGridActive ? 'rgba(60,140,255,0.18)' : 'var(--color-surface-3)',
                color: dewarpGridActive ? '#5b9fff' : 'var(--color-text-2)',
                border: `1px solid ${dewarpGridActive ? 'rgba(60,140,255,0.45)' : 'var(--color-border)'}`,
                boxShadow: dewarpGridActive ? '0 0 12px rgba(60,140,255,0.2)' : 'none',
              }}
            >
              {dewarpGridActive ? '🔵 Re-Analyze Grid' : '🔵 Analyze & Show Grid'}
            </button>

            {/* Strength slider */}
            <div className="field-label">Correction Strength</div>
            <div className="slider-row" style={{ marginTop: 6, marginBottom: 10 }}>
              <input type="range" className="slider" min={0.1} max={2.0} step={0.05}
                value={dewarpStrength} onChange={e => setDewarpStrength(parseFloat(e.target.value))} />
              <span className="slider-value">{dewarpStrength.toFixed(2)}×</span>
            </div>

            <button
              className="btn w-full"
              onClick={() => onDewarp(dewarpStrength)}
              disabled={disabled || !dewarpGridActive}
              id="btn-dewarp"
              style={{
                background: 'linear-gradient(135deg,#00e5ff,#00b4cc)', color: '#07090f',
                boxShadow: (disabled || !dewarpGridActive) ? 'none' : '0 0 18px rgba(0,229,255,0.3)',
              }}
            >
              {loading ? <span className="spinner" /> : '⌇'} Apply Grid Dewarp
            </button>
          </>
        )}
      </StPanel>


      {/* ── Panel 7: Enhancement ── */}
      <StPanel number={7} title="Enhancement">
        <div className="field-label">Method</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 10 }}>
          {[
            { id: 'otsu',     label: 'Otsu B/W',  desc: 'Global threshold' },
            { id: 'adaptive', label: 'Adaptive',   desc: 'Local threshold' },
          ].map(m => (
            <label key={m.id} style={{ cursor: 'pointer' }}>
              <input type="radio" name="enhance-method" value={m.id} style={{ display: 'none' }}
                checked={enhanceType === m.id} onChange={() => setEnhanceType(m.id)} />
              <div style={{
                padding: '8px 10px', borderRadius: 8, cursor: 'pointer',
                border: `1px solid ${enhanceType === m.id ? 'rgba(0,230,118,0.5)' : 'var(--color-border)'}`,
                background: enhanceType === m.id ? 'rgba(0,230,118,0.1)' : 'var(--color-surface-3)',
                transition: 'all 0.15s',
              }}>
                <div style={{ fontSize: 12, fontWeight: 600,
                  color: enhanceType === m.id ? 'var(--color-green)' : 'var(--color-text)' }}>
                  {m.label}
                </div>
                <div style={{ fontSize: 10, color: 'var(--color-text-3)', marginTop: 2 }}>{m.desc}</div>
              </div>
            </label>
          ))}
        </div>

        <div className="field-label">Output Format</div>
        <div className="format-selector" style={{ marginTop: 6 }}>
          {[
            { id: 'bw',        label: 'B/W',   icon: '◧' },
            { id: 'grayscale', label: 'Gray',  icon: '▨' },
            { id: 'color',     label: 'Color', icon: '▦' },
          ].map(f => (
            <label key={f.id} className="format-option">
              <input type="radio" name="output-format" value={f.id}
                checked={outputFormat === f.id} onChange={() => setOutputFormat(f.id)} />
              <div className="format-label"
                style={outputFormat === f.id ? {
                  borderColor: 'rgba(0,230,118,0.5)', background: 'rgba(0,230,118,0.1)',
                  color: 'var(--color-green)',
                } : {}}>
                <span style={{ fontSize: 16 }}>{f.icon}</span>
                {f.label}
              </div>
            </label>
          ))}
        </div>

        <button
          className="btn w-full"
          onClick={() => onEnhance(enhanceType, outputFormat)}
          disabled={disabled}
          id="btn-enhance"
          style={{ marginTop: 10, background: 'linear-gradient(135deg,#00e676,#00b852)', color: '#07090f',
            boxShadow: disabled ? 'none' : '0 0 18px rgba(0,230,118,0.3)' }}
        >
          {loading ? <span className="spinner" /> : '✦'} Apply Enhancement
        </button>
      </StPanel>

      {/* ── Actions (always visible) ── */}
      <div className="st-panel open" style={{ borderLeft: '2px solid var(--color-text-3)' }}>
        <div className="st-panel-header open" style={{ cursor: 'default', opacity: 0.85 }}>
          <span className="st-panel-num">⚙</span>
          <span className="st-panel-title">Actions</span>
        </div>
        <div className="st-panel-body">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6, marginBottom: 6 }}>
            <button className="btn btn-ghost btn-sm" onClick={onUndo}
              disabled={!canUndo || loading} id="btn-undo">↩ Undo</button>
            <button className="btn btn-ghost btn-sm" onClick={onReset}
              disabled={!hasTransformed || loading} id="btn-reset">↺ Reset</button>
          </div>
          <button
            className="btn btn-secondary w-full"
            onClick={onExportPdf}
            disabled={!hasImage || loading}
            id="btn-export"
          >
            ⬇ Export PDF ({pageCount} page{pageCount !== 1 ? 's' : ''})
          </button>
        </div>
      </div>
    </div>
  );
}
