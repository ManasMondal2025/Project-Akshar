import { useRef, useEffect, useState, useCallback } from 'react';

export default function CanvasEditor({
  imageSrc,
  imageWidth,
  imageHeight,
  corners,
  onCornersChange,
  isWarpMode,
  warpPoints,
  onWarpPointsChange,
  warpGridRows = 4,
  warpGridCols = 4,
  dewarpGrid = null,
  onDewarpGridChange = null,
}) {
  const canvasRef    = useRef(null);
  const imgRef       = useRef(null);
  const containerRef = useRef(null);
  const scaleRef     = useRef(1);
  const offsetRef    = useRef({ x: 0, y: 0 });
  // Always holds the latest draw fn — img.onload calls this, no stale closure
  const drawRef      = useRef(null);

  const [draggingCorner,      setDraggingCorner]      = useState(null);
  const [draggingWarpPoint,   setDraggingWarpPoint]   = useState(null);
  const [draggingDewarpPoint, setDraggingDewarpPoint] = useState(null);

  const CORNER_RADIUS     = 10;
  const WARP_POINT_RADIUS = 6;
  const MAX_W             = 900;
  const MAX_H             = 640;

  // ── Draw (memoised for prop-change effect, stored in ref for img.onload) ──
  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !imgRef.current) return;
    const scale  = scaleRef.current;
    const offset = offsetRef.current;
    const ctx    = canvas.getContext('2d');

    canvas.width  = MAX_W;
    canvas.height = MAX_H;

    // Background checkerboard
    ctx.fillStyle = '#0d0d15';
    ctx.fillRect(0, 0, MAX_W, MAX_H);
    const ts = 16;
    for (let ty = 0; ty < MAX_H; ty += ts) {
      for (let tx = 0; tx < MAX_W; tx += ts) {
        ctx.fillStyle = (((tx / ts + ty / ts) % 2) === 0) ? '#12121e' : '#0f0f1a';
        ctx.fillRect(tx, ty, ts, ts);
      }
    }

    // Image
    ctx.drawImage(imgRef.current,
      offset.x, offset.y,
      imgRef.current.width * scale,
      imgRef.current.height * scale,
    );

    // ── ScanTailor dewarp grid overlay ────────────────────────────────────
    if (dewarpGrid && dewarpGrid.detected) {
      const gw = dewarpGrid.width;
      const gh = dewarpGrid.height;
      const gx = (x) => x * scale * (imgRef.current.width  / gw) + offset.x;
      const gy = (y) => y * scale * (imgRef.current.height / gh) + offset.y;
      const nRows = dewarpGrid.row_curves.length;
      const nCols = dewarpGrid.row_curves[0]?.length || 0;

      ctx.setLineDash([]); ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(70,120,255,0.75)';
      for (const row of dewarpGrid.row_curves) {
        if (row.length < 2) continue;
        ctx.beginPath(); ctx.moveTo(gx(row[0][0]), gy(row[0][1]));
        for (let i = 1; i < row.length; i++) ctx.lineTo(gx(row[i][0]), gy(row[i][1]));
        ctx.stroke();
      }
      ctx.lineWidth = 0.8; ctx.strokeStyle = 'rgba(70,120,255,0.65)';
      for (const col of dewarpGrid.col_lines) {
        if (col.length < 2) continue;
        ctx.beginPath(); ctx.moveTo(gx(col[0][0]), gy(col[0][1]));
        for (let i = 1; i < col.length; i++) ctx.lineTo(gx(col[i][0]), gy(col[i][1]));
        ctx.stroke();
      }
      if (nRows >= 2 && nCols >= 2) {
        const tr = dewarpGrid.row_curves[0], br = dewarpGrid.row_curves[nRows-1];
        const lc = dewarpGrid.col_lines[0],  rc = dewarpGrid.col_lines[nCols-1];
        ctx.strokeStyle = 'rgba(255,50,50,0.85)'; ctx.lineWidth = 1.5;
        [[tr],[br],[lc],[rc]].forEach(([pts]) => {
          if (!pts || pts.length < 2) return;
          ctx.beginPath(); ctx.moveTo(gx(pts[0][0]), gy(pts[0][1]));
          for (let i = 1; i < pts.length; i++) ctx.lineTo(gx(pts[i][0]), gy(pts[i][1]));
          ctx.stroke();
        });
        [tr[0], tr[nCols-1], br[0], br[nCols-1]].forEach(cp => {
          const cx = gx(cp[0]), cy = gy(cp[1]);
          ctx.beginPath(); ctx.arc(cx, cy, 6, 0, Math.PI*2); ctx.fillStyle='rgba(255,40,40,0.35)'; ctx.fill();
          ctx.beginPath(); ctx.arc(cx, cy, 3.5, 0, Math.PI*2); ctx.fillStyle='#ff3333'; ctx.fill();
          ctx.beginPath(); ctx.arc(cx, cy, 1.2, 0, Math.PI*2); ctx.fillStyle='#fff'; ctx.fill();
        });
      }
      ctx.font='600 11px Inter,sans-serif'; ctx.fillStyle='rgba(80,130,255,0.9)'; ctx.textAlign='left';
      ctx.fillText(`ScanTailor Grid: ${nRows}×${nCols} mesh · ${dewarpGrid.row_count} text lines`, offset.x+6, offset.y+16);
    }

    // ── Warp mesh overlay ─────────────────────────────────────────────────
    if (isWarpMode && warpPoints && warpPoints.length === warpGridRows * warpGridCols) {
      ctx.strokeStyle = 'rgba(124,77,255,0.4)'; ctx.lineWidth = 1;
      for (let r = 0; r < warpGridRows; r++) {
        ctx.beginPath();
        for (let c = 0; c < warpGridCols; c++) {
          const p = warpPoints[r*warpGridCols+c];
          const sx = p[0]*scale+offset.x, sy = p[1]*scale+offset.y;
          c===0 ? ctx.moveTo(sx,sy) : ctx.lineTo(sx,sy);
        }
        ctx.stroke();
      }
      for (let c = 0; c < warpGridCols; c++) {
        ctx.beginPath();
        for (let r = 0; r < warpGridRows; r++) {
          const p = warpPoints[r*warpGridCols+c];
          const sx = p[0]*scale+offset.x, sy = p[1]*scale+offset.y;
          r===0 ? ctx.moveTo(sx,sy) : ctx.lineTo(sx,sy);
        }
        ctx.stroke();
      }
      warpPoints.forEach((p, i) => {
        const sx=p[0]*scale+offset.x, sy=p[1]*scale+offset.y;
        ctx.beginPath(); ctx.arc(sx,sy,WARP_POINT_RADIUS+2,0,Math.PI*2);
        ctx.fillStyle=draggingWarpPoint===i?'#ff3d7f':'rgba(124,77,255,0.8)'; ctx.fill();
        ctx.beginPath(); ctx.arc(sx,sy,3,0,Math.PI*2); ctx.fillStyle='#fff'; ctx.fill();
      });

    } else if (!isWarpMode && !(dewarpGrid?.detected) && corners?.length===4) {
      // Perspective corner overlay
      const pts = corners.map(c=>({ sx:c.x*scale+offset.x, sy:c.y*scale+offset.y }));
      ctx.beginPath(); pts.forEach((p,i)=>i===0?ctx.moveTo(p.sx,p.sy):ctx.lineTo(p.sx,p.sy));
      ctx.closePath(); ctx.strokeStyle='#00e5ff'; ctx.lineWidth=2; ctx.setLineDash([6,4]); ctx.stroke();
      ctx.setLineDash([]); ctx.fillStyle='rgba(0,229,255,0.06)'; ctx.fill();
      ctx.beginPath(); pts.forEach((p,i)=>i===0?ctx.moveTo(p.sx,p.sy):ctx.lineTo(p.sx,p.sy));
      ctx.closePath(); ctx.strokeStyle='#00e5ff'; ctx.lineWidth=2.5; ctx.stroke();
      pts.forEach(({sx,sy},i)=>{
        ctx.beginPath(); ctx.arc(sx,sy,CORNER_RADIUS+4,0,Math.PI*2); ctx.fillStyle='rgba(0,229,255,0.2)'; ctx.fill();
        ctx.beginPath(); ctx.arc(sx,sy,CORNER_RADIUS,0,Math.PI*2); ctx.fillStyle=draggingCorner===i?'#ff6b35':'#00e5ff'; ctx.fill();
        ctx.beginPath(); ctx.arc(sx,sy,3,0,Math.PI*2); ctx.fillStyle='#fff'; ctx.fill();
        ctx.font='600 11px Inter,sans-serif'; ctx.fillStyle='#fff'; ctx.textAlign='center';
        ctx.fillText(['TL','TR','BR','BL'][i], sx, sy-CORNER_RADIUS-8);
      });
    }
  }, [corners, draggingCorner, isWarpMode, warpPoints, draggingWarpPoint, warpGridRows, warpGridCols, dewarpGrid, draggingDewarpPoint]);

  // Always keep drawRef current — img.onload uses this, never a stale closure
  useEffect(() => { drawRef.current = draw; }, [draw]);

  // ── Image load — depends ONLY on imageSrc, no circular dep with draw ──────
  useEffect(() => {
    if (!imageSrc) return;
    imgRef.current = null;

    const img = new Image();
    img.onload = () => {
      const sx = MAX_W / img.width, sy = MAX_H / img.height;
      const s  = Math.min(sx, sy, 1);
      scaleRef.current  = s;
      offsetRef.current = {
        x: (MAX_W - img.width  * s) / 2,
        y: (MAX_H - img.height * s) / 2,
      };
      imgRef.current = img;
      drawRef.current?.(); // latest draw fn, no stale closure
    };
    img.onerror = () => console.error('[CanvasEditor] Failed to load image:', imageSrc?.slice(0, 80));
    img.src = imageSrc;
  }, [imageSrc]); // ← imageSrc ONLY — no draw dep, no circular effect

  // ── Redraw when overlay props change ──────────────────────────────────────
  useEffect(() => { draw(); }, [draw]);

  // ── Coord helpers ─────────────────────────────────────────────────────────
  const canvasToImage = (cx, cy) => ({
    x: (cx - offsetRef.current.x) / scaleRef.current,
    y: (cy - offsetRef.current.y) / scaleRef.current,
  });

  const getMousePos = (e) => {
    const canvas = canvasRef.current;
    const rect   = canvas.getBoundingClientRect();
    return {
      x: (e.clientX - rect.left) * (canvas.width  / rect.width),
      y: (e.clientY - rect.top)  * (canvas.height / rect.height),
    };
  };

  const findCorner = (mx, my) => {
    if (!corners || isWarpMode) return -1;
    const s = scaleRef.current, o = offsetRef.current;
    for (let i = 0; i < corners.length; i++) {
      if (Math.hypot(mx - (corners[i].x*s+o.x), my - (corners[i].y*s+o.y)) <= CORNER_RADIUS+6) return i;
    }
    return -1;
  };

  const findWarpPoint = (mx, my) => {
    if (!warpPoints || !isWarpMode) return -1;
    const s = scaleRef.current, o = offsetRef.current;
    for (let i = 0; i < warpPoints.length; i++) {
      if (Math.hypot(mx-(warpPoints[i][0]*s+o.x), my-(warpPoints[i][1]*s+o.y)) <= WARP_POINT_RADIUS+8) return i;
    }
    return -1;
  };

  const findDewarpGridPoint = (mx, my) => {
    if (!dewarpGrid?.detected || isWarpMode || !imgRef.current) return null;
    const s=scaleRef.current, o=offsetRef.current, gw=dewarpGrid.width, gh=dewarpGrid.height;
    const gx=(x)=>x*s*(imgRef.current.width/gw)+o.x;
    const gy=(y)=>y*s*(imgRef.current.height/gh)+o.y;
    for (let r=0;r<dewarpGrid.row_curves.length;r++)
      for (let c=0;c<dewarpGrid.row_curves[r].length;c++)
        if (Math.hypot(mx-gx(dewarpGrid.row_curves[r][c][0]), my-gy(dewarpGrid.row_curves[r][c][1]))<=8)
          return {r,c};
    return null;
  };

  // ── Mouse handlers ────────────────────────────────────────────────────────
  const handleMouseDown = (e) => {
    const {x,y} = getMousePos(e);
    if (isWarpMode) {
      const idx = findWarpPoint(x,y);
      if (idx>=0) { setDraggingWarpPoint(idx); e.preventDefault(); }
    } else if (dewarpGrid?.detected && onDewarpGridChange) {
      const pt = findDewarpGridPoint(x,y);
      if (pt) { setDraggingDewarpPoint(pt); e.preventDefault(); }
      else { const idx=findCorner(x,y); if(idx>=0){setDraggingCorner(idx);e.preventDefault();} }
    } else {
      const idx=findCorner(x,y); if(idx>=0){setDraggingCorner(idx);e.preventDefault();}
    }
  };

  const handleMouseMove = (e) => {
    const {x,y} = getMousePos(e);
    const canvas = canvasRef.current;

    if (isWarpMode) {
      canvas.style.cursor = findWarpPoint(x,y)>=0||draggingWarpPoint!==null?'grab':'default';
      if (draggingWarpPoint!==null && warpPoints) {
        const {x:ix,y:iy}=canvasToImage(x,y);
        const np=[...warpPoints];
        np[draggingWarpPoint]=[Math.max(0,Math.min(imageWidth,ix)),Math.max(0,Math.min(imageHeight,iy))];
        onWarpPointsChange(np);
      }
    } else if (dewarpGrid?.detected && onDewarpGridChange) {
      canvas.style.cursor=findDewarpGridPoint(x,y)||draggingDewarpPoint!==null?'grab':findCorner(x,y)>=0||draggingCorner!==null?'grab':'default';
      if (draggingDewarpPoint!==null) {
        const {x:ix,y:iy}=canvasToImage(x,y);
        const gx=Math.max(0,Math.min(dewarpGrid.width, ix*(dewarpGrid.width/imageWidth)));
        const gy=Math.max(0,Math.min(dewarpGrid.height,iy*(dewarpGrid.height/imageHeight)));
        const ng=JSON.parse(JSON.stringify(dewarpGrid));
        const {r:dr,c:dc}=draggingDewarpPoint;
        const dx=gx-ng.row_curves[dr][dc][0], dy=gy-ng.row_curves[dr][dc][1];
        const S2=64;
        for(let c=0;c<ng.row_curves[0].length;c++){const w=Math.exp(-((c-dc)**2)/S2);ng.row_curves[dr][c][0]+=dx*w;ng.row_curves[dr][c][1]+=dy*w;}
        for(let r=0;r<ng.row_curves.length;r++){if(r===dr)continue;const w=Math.exp(-((r-dr)**2)/S2);ng.row_curves[r][dc][0]+=dx*w;ng.row_curves[r][dc][1]+=dy*w;}
        const nc=[];for(let c=0;c<ng.row_curves[0].length;c++){const cl=[];for(let r=0;r<ng.row_curves.length;r++)cl.push([ng.row_curves[r][c][0],ng.row_curves[r][c][1]]);nc.push(cl);}
        ng.col_lines=nc; onDewarpGridChange(ng);
      } else if (draggingCorner!==null && corners) {
        const {x:ix,y:iy}=canvasToImage(x,y);
        const nc=[...corners]; nc[draggingCorner]={x:Math.max(0,Math.min(imageWidth,ix)),y:Math.max(0,Math.min(imageHeight,iy))};
        onCornersChange(nc);
      }
    } else {
      canvas.style.cursor=findCorner(x,y)>=0||draggingCorner!==null?'grab':'default';
      if (draggingCorner!==null && corners) {
        const {x:ix,y:iy}=canvasToImage(x,y);
        const nc=[...corners]; nc[draggingCorner]={x:Math.max(0,Math.min(imageWidth,ix)),y:Math.max(0,Math.min(imageHeight,iy))};
        onCornersChange(nc);
      }
    }
  };

  const handleMouseUp = () => { setDraggingCorner(null); setDraggingWarpPoint(null); setDraggingDewarpPoint(null); };

  return (
    <div className="canvas-editor" ref={containerRef}>
      <canvas
        ref={canvasRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        style={{ borderRadius:'12px', display:'block', width:`${MAX_W}px`, height:`${MAX_H}px` }}
      />
      <div className="canvas-hint">
        {isWarpMode ? (
          <><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#7c4dff" strokeWidth="2"><path d="M4 4h16v16H4zM4 12h16M12 4v16"/></svg>Drag the purple mesh grid points to flatten the document curves</>
        ) : (
          <><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 9l7-7 7 7M5 15l7 7 7-7"/></svg>Drag the corner points to adjust document boundaries</>
        )}
      </div>
    </div>
  );
}
