import { useRef, useState } from 'react';

/**
 * UploadZone — Drag and drop / click to upload PDFs or images.
 * Works in the PROJECT AKSHAR design system.
 */
export default function UploadZone({ onFilesSelect, loading }) {
  const inputRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') setDragOver(true);
    else setDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(false);
    const files = Array.from(e.dataTransfer.files || []);
    if (files.length > 0) onFilesSelect(files);
  };

  const handleChange = (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length > 0) onFilesSelect(files);
    e.target.value = '';
  };

  return (
    <div
      className={`upload-zone ${dragOver ? 'drag-over' : ''}`}
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={handleDrop}
      onClick={() => !loading && inputRef.current?.click()}
      id="upload-zone"
      style={{ cursor: loading ? 'wait' : 'pointer' }}
    >
      <input
        ref={inputRef}
        type="file"
        accept=".pdf,image/*"
        multiple
        onChange={handleChange}
        style={{ display: 'none' }}
        id="file-input"
      />

      {loading ? (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16 }}>
          <div className="spinner" style={{ width: 36, height: 36, borderWidth: 3 }} />
          <p style={{ color: 'var(--color-text-2)', fontSize: 14 }}>Processing…</p>
        </div>
      ) : (
        <>
          <svg className="upload-icon" viewBox="0 0 64 64" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M40 8H16a6 6 0 00-6 6v36a6 6 0 006 6h32a6 6 0 006-6V24L40 8z" />
            <path d="M40 8v16h16" />
            <path d="M32 28v16M24 36l8-8 8 8" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <div className="upload-title">Drop your document here</div>
          <div className="upload-subtitle">
            Drag & drop a PDF or image, or click to browse.<br />
            PDFs are auto-detected as digital or scanned.
          </div>
          <div className="upload-formats">
            {['PDF', 'PNG', 'JPG', 'TIFF', 'BMP'].map(f => (
              <span key={f} className="format-tag">.{f.toLowerCase()}</span>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
